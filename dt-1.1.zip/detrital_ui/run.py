import sys
import common as ba
import plots as ps 
import pymc as pm
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from data_types import *


def InitExhumation(settings):
    """Initialize piece-wise linear exhumation model"""
    #Check that erosion and age break priors are meaningful
    if (settings.erate_prior[0] >= settings.erate_prior[1]):
        print "\nInvalid range for erate_prior."
        sys.exit()
    if (settings.abr_prior[0] >= settings.abr_prior[1]):
        print "\nInvalid range for abr_prior."
        sys.exit()
    #Create erosion rate parameters (e1, e2, ...)
    e = []
    for i in range(1,settings.breaks+2):
        e.append(pm.Uniform("e%i" % i, settings.erate_prior[0], settings.erate_prior[1]))
    #Create age break parameters (abr1, ...)
    abr_i = settings.abr_prior[0]
    abr = []
    for i in range(1,settings.breaks+1):
        abr_i = pm.Uniform("abr%i" % i, abr_i, settings.abr_prior[1])
        abr.append(abr_i)
    return e, abr

def ExhumationModel(settings):
    """Set up the exhumation model"""
    #Check that error rate priors are meaningful
    if (settings.error_prior[0] >= settings.error_prior[1]):
        print "\nInvalid range for error_prior."
        sys.exit()     
    err = pm.Uniform('RelErr',settings.error_prior[0],settings.error_prior[1])
    #Closure elevation priors
    hc_parms={'AFT':[3.7, 0.8, 6.0, 2.9], 'AHe':[2.2, 0.5, 3.7, 1.6]}
    e, abr = InitExhumation(settings)
    nodes = [err, e, abr]
    hc = {}
    for sample in settings.samples:
        parms = e[:]
        h_mu = np.mean(sample.catchment.z)
        if sample.tc_type not in hc.keys(): 
            hc[sample.tc_type] = pm.TruncatedNormal("hc_%s"%sample.tc_type, h_mu-hc_parms[sample.tc_type][0],
                                                    1/hc_parms[sample.tc_type][1]**2,
                                                    h_mu-hc_parms[sample.tc_type][2],
                                                    h_mu-hc_parms[sample.tc_type][3])
            nodes.append(hc[sample.tc_type])
        parms.append(hc[sample.tc_type])
        parms.extend(abr)   
        if isinstance(sample, DetritalSample):
            idx_i = pm.Categorical("Index_" + sample.sample_name, p = sample.catchment.bins['w'], size=len(sample.dt_ages))
            nodes.extend([idx_i])
            exp_i = pm.Lambda("ExpAge_" + sample.sample_name, lambda parm=parms, idx=idx_i: ba.h2a(sample.catchment.bins['h'][idx],parm))
            value = sample.dt_ages
        else:
            idx_i = None
            exp_i = pm.Lambda("ExpAge_" + sample.sample_name, lambda parm=parms: ba.h2a(sample.br_elevation,parm), plot=False)
            value = sample.br_ages
        obs_i = pm.Normal("ObsAge_" + sample.sample_name, mu = exp_i, tau = 1./(err*exp_i)**2, value = value, observed=True)
        sim_i = pm.Lambda("SimAge_" + sample.sample_name, lambda ta=exp_i, err=err: pm.rnormal(mu = ta, tau = 1./(err*ta)**2))
        nodes.extend([exp_i, obs_i, sim_i])
    return nodes
                   
def run_MCMC(settings):
    """Run MCMC algorithm"""
    burn = settings.iterations/2
    thin = (settings.iterations-burn) / settings.finalChainSize
    name = "%s" % settings.model_name + "_%ibrk" % settings.breaks
    attempt = 0
    model=None
    while attempt<5000:
        try:
            model = ExhumationModel(settings)
            
            break
        except pm.ZeroProbability, ValueError:
            attempt+=1
            print "Init failure %i" % attemp
    try:
        #The following creates text files for the chains rather than hdf5
        db = pm.database.txt.load(name + '.txt')
        #db = pm.database.hdf5.load(name + '.hdf5')
        print "\nExisting MCMC data loaded.\n"
    except AttributeError:
        print "\nNo previous MCMC data found.\n"
        db='txt'
       
    mcmc = pm.MCMC(model, db=db, name=name)
    #mcmc.use_step_method(pm.AdaptiveMetropolis, M.parm)
    if settings.iterations > 1: 
        mcmc.sample(settings.iterations,burn=burn,thin=thin)
    return mcmc
                    
if __name__ == '__main__':
    sys.path[0:0] = './' # Puts current directory at the start of path
    import model_setup as ms
    
    if len(sys.argv)>1: ms.iterations = int(sys.argv[1])
    
    M=run_MCMC(ms)
    
    #import pdb; pdb.set_trace()
    
    #Output and diagnostics
    try:
        ba.statistics(M, ms.samples)
    except TypeError:
        print "\nCannot compute stats without resampling (PyMC bug?).\n"
    ps.chains(M, ms.finalChainSize, ms.iterations, ms.samples, ms.output_format)
    ps.summary(M, ms.samples, ms.output_format)
    ps.ks_gof(M, ms.samples, ms.output_format)
    ps.histograms(ms.samples, ms.show_histogram, ms.output_format)    
    ps.discrepancy(M, ms.samples, ms.output_format)
##    ps.unorthodox_ks(M, ms.output_format)
##    try:
##        ps.catchment(M.catchment_dem, format=ms.output_format)
##    except KeyError:
##        print "\nUnable to generate catchment plot."

    M.db.close()


    

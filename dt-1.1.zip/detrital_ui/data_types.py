import numpy as np
import sys

class Catchment:
    
    def _read_hypsometry(self, hypsometry_file, elevation_column):
        """Reads x,y,z/h from hypsometry file"""
        #Set up for reading data
        if isinstance(elevation_column, int):    
            if (elevation_column >= 3):
                #Assume x,y are in columns 1 and 2
                names = 'x,y,z'
                usecols = (0,1,elevation_column-1)
            else:
                names = 'z'
                usecols = (elevation_column-1)
            elevation_column = 'z'
        else:
            usecols, names = None, True
        #Reading data
        try:
            data = np.genfromtxt(hypsometry_file, delimiter=",", names=names, usecols=usecols, dtype=None)
        except IOError:
            print "\nThe specified file path or file name for hypsometry is invalid: %s" % hypsometry_file 
            sys.exit()
        #Get z from data
        try:
            z = data[elevation_column]
            if isinstance(z[0], str):
                print "\nThe hypsometry file has a header; the value of 'elevation_column' was specified as an integer."
                sys.exit()
        except ValueError:
            print "\nThe value specified for 'elevation_column' does not match the data."
            sys.exit()
        #Get x, y from data
        try:
            x = data['x']
            y = data['y']
        except ValueError:
            x = None
            y = None
            print "No x,y data read"
        #Convert h to kilometers        
        if max(z) > 10:
            print "\nWARNING: Converting to km."
            z /= 1000.0    
        return {'x':x, 'y':y, 'z':z}
    
    def _bins(self, hyps):
        """Generates weights (probabilities) from a histogram of hypsometry"""
        h_w, h_edges = np.histogram(hyps, bins=512, normed=False)
        h_w = h_w / float(len(hyps))
        h_b  = h_edges[:-1] + np.diff(h_edges)/2  # Replace bin margins with bin centers
        return {'h':h_b, 'w':h_w}

    def __init__(self, hypsometry_file, elevation_column):
        
        data = self._read_hypsometry(hypsometry_file, elevation_column)
        self.x = data['x']
        self.y = data['y']
        self.z = data['z']
        self.bins = self._bins(data['z'])
              
class DetritalSample:
    
    def _read_ages(self, age_file):
        """Reads ages from the age file"""
        try:
            data = np.genfromtxt(age_file)
        except IOError:
            print "\nThe specified file path or file name for ages is invalid: %s" % age_file
            sys.exit()
        if (data.ndim > 1):
            print "\nAge file is not in the correct format; it has more than one column."
            sys.exit()
        #Check if ages are in Ma
        for i in range(len(data)):
            if (data[i] > 4500):
                print "\nAge data is invalid; at least one age is older than the Earth itself."
                sys.exit()
        return data
    
    def __init__(self, age_file, sample_name, catchment, tc_type):
        
        self.dt_ages = self._read_ages(age_file)
        self.sample_name = sample_name
        self.catchment = catchment
        self.tc_type = tc_type
                
class BedrockSample:

    def _read_bedrock(self, br_file):
        """Reads elevations, ages, and standard deviations of ages from the bedrock file"""
        try:
            br_data = np.genfromtxt(br_file, delimiter=",", names=True, dtype=None)
        except IOError:
            print "\nThe specified file path or file name for bedrock data is invalid: %s" % br_file
            sys.exit()
        #The following assumes the bedrock data has headers 'alt', 'age', and 'age_sd'
        try:
            br_elev = br_data['alt'].astype(float)
            br_ages = br_data['age']
            br_ages_sd = br_data['age_sd']
        except ValueError:
            print "\nThe header of br_file is not in the proper format."
            sys.exit()
        #Convert elevations to kilometers
        if max(br_elev) > 10:
            br_elev /= 1000.0
    
        return {'br_elev':br_elev, 'br_ages':br_ages, 'br_ages_sd':br_ages_sd}
    
    def __init__(self, br_file, sample_name, catchment, tc_type):

        data = self._read_bedrock(br_file)
        self.br_elevation = data['br_elev']
        self.br_ages = data['br_ages']
        self.br_ages_sd = data['br_ages_sd']
        self.sample_name = sample_name
        self.catchment = catchment
        self.tc_type = tc_type
        
    
       

"""
Utility functions for detrital modeling.
"""

__author__="Boris Avdeev, borisaqua@gmail.com"


import pymc as pm
import numpy as np
import scipy as sp
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import sys
from data_types import *

def sig2tau(sig):
    """Standard deviation to precision"""
    return 1./(sig**2)

def tau2sig(tau):
    """Precision to standard deviation"""
    return (1./tau)**.5

def sample_wr(population, size):
    """Chooses 'size' random elements (with replacement) from a population"""
    n = len(population)
    js = np.array(np.random.random(size) * n).astype('int') 
    return population[js]

def parm2ha(parm, ub, ub_type):
    """Convert parameter vector of an exhumation model [ e1, e2, e3, ... ,hc, abr1, abr2, ... ]
    into ([elevation], [age]) array for plotting"""
    parm = np.array(parm).flatten()
    segs = len(parm)/2
    e = parm[0:segs]
    hc= parm[segs]
    a = [0]
    h = [hc]
    if segs > 1:
        a.extend(parm[segs+1:])
        da = np.diff(a)
        for i in range(segs-1):
            h.append(h[i] + e[i]*da[i])
    if not (ub_type=='h' or ub_type=='a'): 
        raise NameError('ub_type must be either a or h')
    if ub_type=='h' and ub > h[-1]:
        h.append(ub) 
        a.append(a[-1] + (ub - h[-2]) / e[-1])
    elif ub_type=='a' and ub > a[-1]:
        a.append(ub) 
        h.append(h[-1] + (ub - a[-2]) * e[-1])
    return np.array(h), np.array(a)

def h2a(hyps, parm):
    """Convert elevations to ages given parm = [ e1, e2, e3, ... ,hc, abr1, abr2, ... ] """
    h,a = parm2ha(parm,max(hyps),'h')
    if len(a)==1: return np.repeat(np.nan,len(hyps)) 
    fun = interp1d(h, a, bounds_error=False, fill_value=np.nan) #or 0???
    return fun(hyps)

def a2h(ages, parm):
    """Convert ages to elevations given parm = [ e1, e2, e3, ... ,hc, abr1, abr2, ... ] """
    [h,a] = parm2ha(parm,max(ages),'a')
    fun = interp1d(a, h, bounds_error=False, fill_value=0)
    return fun(ages)
    
@pm.randomwrap
def detrital_random(hyps,hyps_w,parm,err,size=None):
    """Random detrital sample. hyps -- bins. BAD? Should probably
       supply weighting function and DEM and sample from there."""
    if len(hyps_w)==1: idx=range(len(hyps))  #WARNING!
    else: idx = hyps_w > pm.runiform(0,max(hyps_w),len(hyps_w))
    ta = h2a(hyps[idx],parm)
    ta_samp = sample_wr(ta, size)    
    return pm.rnormal(ta_samp,sig2tau(err*ta_samp))

def statistics(mcmc, samples):
    """Output statistics for e1, e2, ..., hc"""
    f=open('statistics.csv', 'w')
    f.write("Parameter, Mean, Standard Deviation, 95% Lower, 95% Upper\n")
    #Get parameters (without RelErr)
    parms = get_parms(mcmc, samples, RelErr=False)
    for parm in parms:
        parm_name = str(parm)
        stats = mcmc.stats()[parm_name]
        f.write(str(parm_name) + ", ")
        f.write("%f, %f, %f, %f\n" % (stats['mean'], stats['standard deviation'], stats['95% HPD interval'][0], stats['95% HPD interval'][1]))
    f.close()

def get_parms(mcmc, samples, RelErr):
    """Extracts a list of the parameters in the model. If RelErr is true it is returned as a parameter"""
    #Get the parameters
    index_list = []
    for sample in samples:
        if isinstance(sample, DetritalSample):
            index_list.append("Index_" + sample.sample_name)
    parameters = []
    for item in mcmc.stochastics:
        if not(str(item) in index_list):
            parameters.append(item)
            
    #Order the parameters
    size = len(mcmc.stochastics)-len(index_list)
    e_size = (size-1)/2
    abr_size = e_size-1 #This is the number of breaks	
           
    hc_storage = []
    relErr_storage = []
    temp_e = []
    temp_abr = []

    for parm in parameters:
	#hc
        if (str(parm) == "hc_%s"%sample.tc_type):
            hc_storage.append(parm)
        #RelErr
	if (str(parm) == "RelErr"):
	    relErr_storage.append(parm)
	#e1, e2, ...
	for i in range(e_size+1):
	    if (str(parm) == "e%i" % i):
      		temp_e.append(parm)     #Not in order!
	#abr1, ...
        for i in range(abr_size+1):
            if (str(parm) == "abr%i" % i):
                temp_abr.append(parm)       #Not in order!
    #Order e1, e2, ...
    e_storage = []
    for i in range(e_size+1):
        for j in range(len(temp_e)):
            if (str(temp_e[j]) == "e%i" % (i+1)):
                e_storage.append(temp_e[j])
    #Order abr1, ...
    abr_storage = []
    for i in range(abr_size+1):
        for j in range(len(temp_abr)):
            if (str(temp_abr[j]) == "abr%i" % (i+1)):
                abr_storage.append(temp_abr[j])    
    
    #Take out RelErr if necessary
    if (RelErr==True):
    	ordered_parameters = e_storage + hc_storage + abr_storage + relErr_storage           
    else:
	ordered_parameters = e_storage + hc_storage + abr_storage

    return ordered_parameters






















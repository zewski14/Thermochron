from data_types import *

# Follow the instructions below and edit the appropriate classes and variables.

#---------------------------------------------Data--------------------------------------------


#----------Detrital Sample(s)----------

# Each detrital sample requires catchment information that must be provided to the Catchment class. Provide the catchment
# number, hypsometry file, and elevation column. The hypsometry file must be a comma delimited. The data should be in columns.
# If a header is present in the hypsometry file (i.e. the top row in the file reads "x, y, z" or "x, y, h"), then set
# 'elevation_column' to the appropriate character 'z' or 'h' (string type variable). If no header is present, specify the
# number of the appropriate column (integer type variable).

# Each sample also requires information provided to the Detrital class. Provide a sample number, age file, sample name, the
# proper catchment, and the thermochronometer type. The proper format for the age file is a single column of ages with no
# header. Ages should be in millions of years. The thermochronometer type can be either 'AFT' (Apatite fission track) or 'AHe'
# (Apatite helium). 


# FIRST DETRITAL SAMPLE

#Catchment information
catchment_1 = Catchment(hypsometry_file = "../data/Inyo.xyhs", elevation_column = 'h')

#Detrital information
sample_1 = DetritalSample(age_file = "../data/InyoAges.txt", sample_name = 'Inyo_dt', catchment = catchment_1, tc_type = 'AHe')


# SECOND DETRITAL SAMPLE

#Catchment information
catchment_2 = Catchment(hypsometry_file = "../data/Pine.xyhs", elevation_column = 'h')

#Detrital information
sample_2 = DetritalSample(age_file = "../data/PineAges.txt", sample_name = 'Pine_dt', catchment = catchment_2, tc_type = 'AHe')


#----------Bedrock Sample(s)----------

# In addition to a detrital sample you can provide a bedrock sample (optional). Provide the bedrock sample number, the bedrock
# file, the bedrock sample name, the appropriate catchment, and the thermochronometer type. The bedrock data must be comma delimited.
# The data should be in columns with a single header line. To run without bedrock data add no additional sample here.


# FIRST BEDROCK SAMPLE

#Bedrock information
sample_3 = BedrockSample(br_file = "../data/bedrock.csv", sample_name = 'Inyo_br', catchment = catchment_1, tc_type = 'AHe')


#----------List of Sample(s)----------

# The following is a list containing all samples defined above. The list must have at least one sample.
samples = [sample_1, sample_2, sample_3]


#--------------------------------------------Model----------------------------------------------

# Enter a name for the model.

model_name = "Inyo_Pine"

# Enter an integer representing the number of breaks in the exhumation model.
breaks = 2

# Enter a range for the following priors.
erate_prior = (0, 1)
abr_prior = (0, 40)
error_prior = (0.1, 0.15) # 'error_prior' is relative error, the bounds are percentages

# Enter the desired amount of iterations for the MCMC algorithm.
iterations = 10000  

# Enter the desired size of the resulting chain.
finalChainSize = 1000

#------------------------------Output------------------------------------------

# Indicate whether or not histograms for ages and elevations of detrital samples will be provided in output.
# Enter either "True" or "False".

show_histogram = "True"

# Enter the desired output format for plots/figures.
# Example: "pdf", "png", "jpeg", etc.

output_format = "png"


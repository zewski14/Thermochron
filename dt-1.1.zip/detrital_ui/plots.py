"""
Plotting functions for detrital modeling
"""

import pymc as pm
import numpy as np
import scipy as sp
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import sys
import common as ba
import mpl_toolkits.axes_grid as ag
from data_types import *


def ecdf_lines(observations, a=None, b=None, color='black'):
    """Plots ecdf as a line"""
    def __ecdf(x):
        counter = 0.0
        for obs in observations:
            if obs <= x:
                counter += 1
        return counter / len(observations)

    if a == None: a = observations.min() - observations.std()/2
    if b == None: b = observations.max() + observations.std()/2
    X = np.linspace(a, b, 100)
    f = np.vectorize(__ecdf)
    plt.plot(X, f(X), color=color,alpha=0.01)
    
def ecdf_points(obs,hpd=None,color='black'):
    """Plots ecdf as a point"""
    obs=np.array(obs)
    idx = np.argsort(obs)
    cdf = np.linspace(0,1,len(obs))
    if hpd is None:
        plt.plot(obs[idx],cdf,'.',color=color)
    else:
        plt.errorbar(obs[idx],cdf,xerr=np.abs(hpd[:,idx]-obs[idx]),fmt='.')

def gof(obs,sim,obs_hpd=None, obs_color='black',sim_color='0.3', color=None):
    """Creates gof plot for detrital data"""
    if color is not None:
        obs_color, sim_color = color, color
    for sim_i in sim:
        ecdf_lines(sim_i,color=sim_color)
    ecdf_points(obs,obs_hpd,color=obs_color)
    
def ah(parms, h_max, color='black'):
    """Generates and plots age/elevation lines between 0 and h_max"""
    for parm in parms:
        h, a = ba.parm2ha(parm, h_max, 'h')
        plt.plot(a,h,color=color,alpha=0.01)

def ks_gof(mcmc, samples, format="png"):
    """Runs ks_2samp test and plots Observed/Expected vs. Simulated/Expected"""
    size = len(samples)
    #Check for bedrock data
    for sample in samples:
        if isinstance(sample, BedrockSample):
            size = len(samples)-1
    #Set size and create grid
    if size == 1:
        fig = plt.figure(figsize=(10, 10))
    else:
        fig = plt.figure(figsize=(6, 10))
    grid = ag.axes_grid.Grid(fig, 111, nrows_ncols = (size, 1), axes_pad = 1, share_x=False, share_y=False, label_mode = "all" )
    j = 0 
    for sample in samples:
        if isinstance(sample, DetritalSample):
            for node in mcmc.nodes:
                if (str(node) == "ObsAge_" + sample.sample_name):
                    obs = node
                elif (str(node) == "SimAge_" + sample.sample_name):
                    sim = node
                elif (str(node) == "ExpAge_" + sample.sample_name):
                    exp = node
            d_simExp=[]
            d_obsExp=[]
            for i in range(len(mcmc.trace(str(exp))[:])):
                D, P = sp.stats.ks_2samp(mcmc.trace(str(exp))[i], mcmc.trace(str(sim))[i])
                d_simExp.append(D)
                D, P = sp.stats.ks_2samp(mcmc.trace(str(exp))[i], obs.value)
                d_obsExp.append(D)
                
            #The test statistics generated from ks_2samp plot as a grid. The following adds
            #random uniform noise for a better visual representation on the plot.
            noise=(0.5/len(obs.value))
            for i in range(len(d_simExp)):
                d_simExp[i] = d_simExp[i] + np.random.uniform(-noise, noise, 1)
                d_obsExp[i] = d_obsExp[i] + np.random.uniform(-noise, noise, 1)

            #Calculate p-value (The proportion of test statistics above the y=x line)
            count=0
            for i in range(len(d_simExp)):
                if (d_simExp[i]>d_obsExp[i]):
                    count=count+1
            count=float(count)
            p_value=(count/len(d_simExp))
    
            #Plot
            grid[j].scatter(d_obsExp, d_simExp, color='gray', edgecolors='black')
            grid[j].set_xlabel('Observed/Expected', fontsize='small')
            grid[j].set_ylabel('Simulated/Expected', fontsize='small')
            label = sample.sample_name + ", " + "p-value="+"%f"%p_value
            grid[j].set_title(label, fontsize='medium')

            #Add a y=x line to plot
            if (max(d_simExp)>=max(d_obsExp)):
                grid[j].plot([0,max(d_simExp)],[0,max(d_simExp)], color='black')
            else:
                grid[j].plot([0,max(d_obsExp)],[0,max(d_obsExp)], color='black')
            j+=1
            
            
    plt.suptitle('Kolmogorov-Smirnov Statistics', fontsize='large')
    fig.savefig("KS_test."+format)

def summary(mcmc, samples, format="png", chain=-1):
    """Creates the summary plot"""
    fig = plt.figure()
    fig.set_size_inches(6.,10.)
    
#     SHOULD BE FIXED
#     Will this work if there are more than one br sample?
#     Looping through samples twice doesnt make sense.
#     Should just loop once, checking for type of sample every time and deciding how to plot things.

    #Check for bedrock data
    for sample in samples:
        if isinstance(sample, BedrockSample):
            for node in mcmc.nodes:
                if (str(node) == "SimAge_" + sample.sample_name):
                    br_sim = node
            br_ages = sample.br_ages
            br_elev = sample.br_elevation
            br_flag = True
        else:
            br_flag = False
            
    #Plot ecdf's for detrital samples
    plotNum=1
    if (br_flag==True):
        numRows=len(samples)
    else:
        numRows=len(samples)+1
    for sample in samples:
        if isinstance(sample, DetritalSample):
            for node in mcmc.nodes:
                if (str(node) == "ObsAge_" + sample.sample_name):
                    obs = node
                elif (str(node) == "SimAge_" + sample.sample_name):
                    sim = node
            try:
                plt.subplot(numRows, 1, plotNum, sharex=plt.gca()) #share axes for previous edcf's
            except UnboundLocalError:
                plt.subplot(numRows, 1, plotNum) 
            p1 = gof(obs.value,mcmc.trace(str(sim),chain=chain)[:])
            plt.ylabel('Empirical CDF')
            plt.title(sample.sample_name, fontsize='medium')
            plotNum+=1
    p2 = plt.subplot(numRows, 1, plotNum, sharex=plt.gca())
    
    #Plot bedrock data and set axes
    lowerElev = np.mean(mcmc.trace("hc_%s"%sample.tc_type)[:])
    if (br_flag == True):   
        for i in range(len(mcmc.trace(br_sim)[:])):
            plt.scatter(mcmc.trace(br_sim)[i], br_elev, s=3, color='black', edgecolors=None, alpha=0.1)
        plt.scatter(br_ages, br_elev, color='white', edgecolors='black')
        upperElev=max(br_elev)+0.1*max(br_elev)
    else:
        upperElev=max(sample.catchment.z)
    lowerAge = 0
    upperAge = max(obs.value)+0.1*max(obs.value)
    
    #Get parameters (without RelErr)
    parm_list = ba.get_parms(mcmc, samples, RelErr=False)
    parms = np.vstack(par.trace(chain=chain) for par in parm_list).transpose()
    
    #Plot traces
    ah(parms, upperElev)
    
    #Apply axes
    p2.set_ylim(lowerElev,upperElev)
    p2.set_xlim(lowerAge,upperAge)
    plt.xlabel('Age (Ma)')
    plt.ylabel('Elevation (km)')
    
    #Plot MAP estimate
    map_idx = np.argmin(mcmc.trace('deviance')[:])
    parm_map=[mcmc.trace(p)[map_idx,] for p in parm_list]
    h, a = ba.parm2ha(parm_map, upperElev, 'h')
    plt.plot(a, h, color='red')

    fig.savefig("Summary." + format)
     
def histograms(samples, show_histogram, format="png"):
    """Plots histograms of age data and hypsometry data for each detrital sample"""
    #Check for histogram option
    if (show_histogram == "True"):
        size = len(samples)
        #Check for bedrock data
        for sample in samples:
            if isinstance(sample, BedrockSample): size -= 1
        #Set size and create grid
        fig = plt.figure(figsize=(10, size*4+2))
        grid = ag.axes_grid.Grid(fig, 111, nrows_ncols = (size, 2), axes_pad = 1, share_x=False, share_y=False, label_mode = "all" )
        i = 0 
        for sample in samples:
            if isinstance(sample, DetritalSample):
                #Elevation
                grid[i].hist(sample.catchment.z, facecolor='gray')
                grid[i].set_xlabel(sample.sample_name + ' Elevation (km)')
                #grid[i].set_ylabel('Frequency')
                i+=1
                
                #Ages
                grid[i].hist(sample.dt_ages, facecolor='gray')
                grid[i].set_xlabel(sample.sample_name + ' Age (Ma)')
                #grid[i].set_ylabel('Frequency')
                i+=1
                
        fig.savefig("Histograms." + format)
        
def catchment(xyz, size = 75, format="png"):
    """Creates a catchment graphic"""
    #ISSUES!
    #This function needs to be fixed so it doesn't interpolate
    #catchment dem from a subsample of data in a convex hull
    from matplotlib.mlab import griddata

    #from  numpy.random import  sample
    idx = np.random.random_integers(0,len(xyz[0])-1, size**2)
    x=xyz[0][idx]
    y=xyz[1][idx]
    z=xyz[2][idx]
    
    xi=np.linspace(min(x), max(x), size*2)
   
    yi=np.linspace(min(y), max(y), size*2)

    zi=griddata(x, y, z, xi, yi)#, interp='linear')
       
    fig = plt.figure()
    plt.imshow(zi,extent = (xi[0],xi[-1],yi[0],yi[-1]), origin = "lower")
    fig.savefig("Catchment."+format)

def chains(mcmc, chainSize, iterations, samples, format="png"):
    """Plots the thinned chain and a histogram for each parameter"""
    #Create a custom x-axis for the chains
    float(chainSize)
    float(iterations)
    burn = iterations/2.
    x = []
    x.append((burn + (iterations-burn)/chainSize))
    for i in range(chainSize-1):
        x.append((x[i] + (iterations-burn)/chainSize))
    x = np.array(x)/1000.0       

    fig = plt.figure(figsize=(15, 20))
    dev = mcmc.trace('deviance')[:]
    #Get parameters (including RelErr)
    parms = ba.get_parms(mcmc, samples, RelErr=True)

    size = len(parms)  
    grid = ag.axes_grid.Grid(fig, 111, nrows_ncols = (size, 2), axes_pad = .3, share_all=False, label_mode = "L" )
    i=0
    for parm in parms:
        grid[i].plot(x, mcmc.trace(parm)[:], c='k')
        grid[i].set_ylabel(parm)
        grid[i].set_xlabel("1e3 Iteration")
        parm_map = mcmc.trace(parm)[np.argmin(dev),]
        grid[i].plot((x[0],max(x)),(parm_map, parm_map), c='r') #Adds MAP estimate
        i+=1
        grid[i].hist(mcmc.trace(parm)[:], orientation='horizontal', fc='gray')
        grid[i].plot((0,0.7*chainSize),(parm_map, parm_map), c='r')  #Adds MAP estimate
        grid[i].set_xlabel("Frequency")
        i+=1
    
    plt.savefig("Chains."+format)

def discrepancy(mcmc, samples, format="png"):    
    """Plots the discrepancy plots for each detrital AND bedrock sample"""
    #Set size and create grid
    size = len(samples)
    if size == 1:
        fig = plt.figure(figsize=(10, 10))
    else:
        fig = plt.figure(figsize=(6, 10))
    grid = ag.axes_grid.Grid(fig, 111, nrows_ncols = (size, 1), axes_pad = 1, share_x=False, share_y=False, label_mode = "all" )
    j = 0 
    for sample in samples:
        name = "D_gof_"
        for node in mcmc.nodes:
            if (str(node) == "ObsAge_" + sample.sample_name):
                obs = node
            elif (str(node) == "SimAge_" + sample.sample_name):
                sim = node
            elif (str(node) == "ExpAge_" + sample.sample_name):
                exp = node
                
        #Discrepancy statistics        
        D_obs, D_sim = pm.discrepancy(obs.value, mcmc.trace(str(sim))[:], mcmc.trace(str(exp))[:])

        #Calculate p-value (The proportion of test statistics above the y=x line)
        count=0
        for i in range(len(D_obs)):
            if (D_sim[i]>D_obs[i]):
                count=count+1
        count=float(count)
        p_value=(count/len(D_obs))

        #Plot
        grid[j].scatter(D_obs, D_sim, color='gray', edgecolors='black')
        grid[j].set_xlabel('Observed deviates', fontsize='small')
        grid[j].set_ylabel('Simulated deviates', fontsize='small')
        label = sample.sample_name + ", " + "p-value="+"%f"%p_value
        grid[j].set_title(label, fontsize='medium')
            
        #Add a y=x line to plot
        if (max(D_sim)>=max(D_obs)):
            grid[j].plot([0,max(D_sim)],[0,max(D_sim)], color='black')
        else:
            grid[j].plot([0,max(D_obs)],[0,max(D_obs)], color='black')
        j+=1
       
    plt.suptitle('Discrepancy Statistics', fontsize='large')
    fig.savefig("Discrepancy_Plot."+format)


##def unorthodox_ks(mcmc, format="png"):
##    """Runs test similar to ks_2samp, but compares horizontal distance between CDF's"""
##    d_simExp=[]
##    d_obsExp=[]
##    sorted_obs=np.sort(mcmc.dt_obs.value)
##    for i in range(len(mcmc.dt_exp.trace())):
##
##        sorted_exp=np.sort(mcmc.dt_exp.trace()[i])
##        sorted_sim=np.sort(mcmc.dt_sim.trace()[i])
##
##        j=np.argmax(abs(sorted_exp-sorted_sim))
##        d_stat=abs(sorted_exp[j]-sorted_sim[j]) 
##        d_simExp.append(d_stat)
##        
##        j=np.argmax(abs(sorted_exp-sorted_obs))
##        d_stat=abs(sorted_exp[j]-sorted_obs[j]) 
##        d_obsExp.append(d_stat)
##    
##    fig = plt.figure()
##    plt.scatter(d_simExp, d_obsExp)
##    fig.savefig("Alternate_ks."+format)


    
